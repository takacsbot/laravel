@extends('layout')

@section('content')
<h1>"{{$category->name }}" kategória részletek</h1>

TODO a kapcsolódó AI tools listája

@endsection