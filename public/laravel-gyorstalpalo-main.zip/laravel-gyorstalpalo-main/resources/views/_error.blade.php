@error('name')
<div class="alert alert-warning">{{ $message }}</div>
@enderror