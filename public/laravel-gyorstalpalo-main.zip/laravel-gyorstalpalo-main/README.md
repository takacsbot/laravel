# Laravel Gyorstalpaló

Kódok a [WebMánia YouTube csatornán](https://youtu.be/ApIbkBLV_yc) megjelent Laravel Gyorstalpaló videókhoz.

## Ha használod az sql dumpot

A 12345678 jelszóval tudsz belépni
